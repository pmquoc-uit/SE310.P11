Terms and conditions:
--------------------------------------------------------------------------------------------------
Fonts Link;

https://fonts.google.com/specimen/Arial
https://fonts.google.com/specimen/Montserrat


--------------------------------------------------------------------------------------------------


All our resources can be used for both personal and commercial projects.
 
We are not liable for the misuse of the resources we provide you. They can be customized and modified to fit your requirements.
     
Redistribution, resells, lease, license, sub-license or offering our resources to third party is not allowed. This includes uploading our resources to another website and offering our resources as a separate attachment from any of your work.
 
All our resources can be used by you or by the clients you purchase it for.
 
Some images are taken from pixabay.com, which are commercial free. 


Please read the below before you proceed using our templates : 

https://www.template.net/license-agreement
https://www.template.net/terms-and-conditions
https://www.template.net/usage-terms


--------------------------------------------------------------------------------------------------

Contact support@template.net for any other queries
